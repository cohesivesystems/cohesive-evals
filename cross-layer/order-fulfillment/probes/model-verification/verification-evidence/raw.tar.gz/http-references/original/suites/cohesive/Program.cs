using System.Text.Json;
using Cohesive.Execution;
using Cohesive.Model.Serialization;
using Cohesive.Transitions.Assurance;
using Fulfillment.Application;

var domain = new FulfillmentDomain();
var transition = domain.InventoryTransitions.Reserve;
var probe = TransitionAssurance.Prepare(transition);
if (args[0] == "--describe")
{
    Console.WriteLine(ExecutionDefinitionJsonSerializer.Serialize(transition.Document));
    return;
}
if (args[0] == "--unsupported-control")
{
    // An authored compound guard must be refused, even when an earlier guard could reject.
    var unsupported = domain.Inventory.Transition<StockQuantity, bool>(
        new("audit/compound"), new("1"), t => t
            .Requires((s, input) => input.Quantity > 0 && input.Quantity < 10, (_, _) => false)
            .Return(true));
    try
    {
        TransitionAssurance.Prepare(unsupported).GenerateInputs(new("control", "local", 7, 4, false), new(0));
        throw new InvalidOperationException("Unsupported generator control unexpectedly succeeded.");
    }
    catch (TransitionInputGenerationException error)
    {
        Console.WriteLine(JsonSerializer.Serialize(new { kind = "unsupported", code = error.Code, node = error.Node.Value, detail = error.Message }));
    }
    return;
}
if (args[0] == "--generate")
{
    var nodes = new SortedSet<string>(StringComparer.Ordinal);
    var provenance = new List<object>();
    var seed = CaseCatalog.Template;
    var options = new StateCaseOptions<InventoryItem>()
        .Range(s => s.Available, CaseCatalog.MinimumStock, CaseCatalog.Maximum)
        .Range(s => s.MaxPerOrder, CaseCatalog.MinimumLimit, CaseCatalog.Maximum);
    var groups = probe.GenerateCases(new(seed.Sku, "local", seed.Available, seed.MaxPerOrder, seed.Quarantined), new(0), options);
    var pairs = new List<(State, int)>();
    foreach (var group in groups)
    {
        var state = new State(group.State.Sku, group.State.Available, group.State.MaxPerOrder, group.State.Quarantined);
        var proposals = group.Commands;
        foreach (var node in proposals.InspectedNodes) nodes.Add(node.Value);
        provenance.Add(new
        {
            state,
            profile = proposals.Profile,
            minimum = proposals.Minimum,
            maximum = proposals.Maximum,
            maxInputs = proposals.MaxInputs,
            coverageLimits = proposals.CoverageLimits,
            candidates = proposals.Candidates.Select(candidate => new
            {
                quantity = candidate.Input.Quantity,
                motivatingNodes = candidate.MotivatingNodes.Select(node => node.Value)
            })
        });
        pairs.AddRange(proposals.Inputs.Select(input => (state, input.Quantity)));
    }
    var generated = CaseCatalog.Freeze(pairs);
    Console.WriteLine(JsonSerializer.Serialize(new
    {
        cases = generated,
        generationCoverage = nodes,
        generationProvenance = provenance,
        modelReference = new
        {
            definitionId = probe.Reference.DefinitionId.Value,
            revisionId = probe.Reference.RevisionId.Value,
            fingerprint = new
            {
                algorithm = probe.Reference.Fingerprint.Algorithm,
                canonicalization = probe.Reference.Fingerprint.Canonicalization,
                value = probe.Reference.Fingerprint.Value
            }
        }
    }));
    return;
}

var cases = JsonSerializer.Deserialize<Case[]>(File.ReadAllText(args[0]))!;
var results = cases.Select(c =>
{
    var result = probe.Execute(new(c.Sku, "local", c.Available, c.MaxPerOrder, c.Quarantined),
        new StockQuantity(c.Quantity), new(c.Name));
    var state = result.State;
    return new Result(c.Name, result.Outcome.Outcome.ToString(), result.Outcome.FulfillmentOutcome.ToString(),
        new(state.Sku, state.Available, state.MaxPerOrder, state.Quarantined), state.Partition == "local");
});
Console.WriteLine(JsonSerializer.Serialize(results));
